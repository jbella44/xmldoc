#!/usr/bin/env python3
# coding: utf-8

"""artconv : convertisseur d'article XML

Utilisation :
  artconv <document> <format>

Description :
  Crée un document au format <format> à partir de <document>.
  <document> doit être un document XML valide.
"""

import os
import sys
try:
    import garden
except ImportError as e:
    print("Installez le module 'garden' ou copiez son sous-dossier 'garden'."
          "\n<https://gitlab.com/frabad/garden/>")
    sys.exit(1)
"""
définition des actions possibles
"""
pipeline = garden.Pipeline((
    garden.Pipeline.Step("docbook", None, "xsltproc", "OASIS DocBook XML"),
    garden.Pipeline.Step("html", "docbook", "xsltproc", "W3C eXtensible HTML"),
    garden.Pipeline.Step("fo", "docbook", "xsltproc", "W3C XSL Formatting Objects"),
    garden.Pipeline.Step("rtf", "fo", "fo2rtf", "Microsoft Word Rich Text Format"),
    garden.Pipeline.Step("pdf", "fo", "fop", "Adobe Portable Document Format")
))

def _transform(source,outform):
    """transforme une entrée vers un format de sortie
    
    Une sortie DocBook intermédiaire est toujours générée par défaut
    Toute autre sortie sera générée à la demande selon la valeur de 
    l'argument outform.
    
    """
    docbook = pipeline.transform(source,"docbook",cleanup=False)
    if outform == "docbook":
        return docbook
    elif outform in ("html","fo"):
        return pipeline.transform(docbook,outform)
    elif outform in ("pdf","rtf"):
        fo = pipeline.transform(docbook,"fo")
        return pipeline.transform(fo,outform)

def transform(source,outform):
    """gère une commande de transformation"""
    
    resultat = os.path.splitext(source)[0] + "." + outform
    sortie = _transform(source,outform)
    if sortie:
        os.rename(sortie,resultat)
        print("[INFO] %s a été généré correctement." % resultat)
        sys.exit(0)
    else:
        print("[ERREUR] impossible de générer le fichier %s." % resultat)
        sys.exit(1)

if __name__ == "__main__":
    """
    vérification  de la commande utilisateur et des ressources invoquées
    """
    usr = garden.args("_exe","source","outform")
    if not usr.source:
        print(__doc__)
        sys.exit(1)
    elif not(os.path.exists(usr.source)):
        print("Le fichier %s est introuvable." % usr.source)
        sys.exit(1)
    elif usr.outform not in pipeline.abilities:
        print(
            "Le format de sortie '%s' est inconnu." % (usr.outform or "aucun"),
            "\nFormats disponibles :", ", ".join(pipeline.abilities)
        )
        sys.exit(1)
    else:
        transform(usr.source,usr.outform)

